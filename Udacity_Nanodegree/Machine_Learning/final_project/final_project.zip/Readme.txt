This zip file contains the following files:

1. final_project.ipynb: my work with full code, description and explanation
2. poi_id.py: only few code that can be exported as pkl files. See final_project.ipynb to see the full context
3. pkl files that are exported from poi_id.py
4. Other original files