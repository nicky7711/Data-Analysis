This compressed file has the followings as requirements:

1. The RMD file containing the analysis
2. The HTML file knitted from the RMD file using the knitr package
3. N/A as I used the file from Udacity (wineQualityReds.csv)
4: N/A